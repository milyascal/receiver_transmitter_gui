﻿namespace gui_demo2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cBOXPARITYBITS = new System.Windows.Forms.ComboBox();
            this.cBOXSTOPBITS = new System.Windows.Forms.ComboBox();
            this.cBOXDATABITS = new System.Windows.Forms.ComboBox();
            this.cBOXBAUDRATE = new System.Windows.Forms.ComboBox();
            this.cBOXCOMPORT = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.btnCLOSE = new System.Windows.Forms.Button();
            this.btnOPEN = new System.Windows.Forms.Button();
            this.btnSENDDATA = new System.Windows.Forms.Button();
            this.tBOXDATAOUT = new System.Windows.Forms.TextBox();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnCLEARDATAOUT = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnCLEARDATAIN = new System.Windows.Forms.Button();
            this.tBOXDATAIN = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.tempChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tempChart)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumBlue;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(43, 620);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(43, 144);
            this.panel2.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cBOXPARITYBITS);
            this.groupBox1.Controls.Add(this.cBOXSTOPBITS);
            this.groupBox1.Controls.Add(this.cBOXDATABITS);
            this.groupBox1.Controls.Add(this.cBOXBAUDRATE);
            this.groupBox1.Controls.Add(this.cBOXCOMPORT);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(49, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(287, 213);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = " Com Port Control";
            // 
            // cBOXPARITYBITS
            // 
            this.cBOXPARITYBITS.FormattingEnabled = true;
            this.cBOXPARITYBITS.Items.AddRange(new object[] {
            "None",
            "Odd",
            "Even"});
            this.cBOXPARITYBITS.Location = new System.Drawing.Point(160, 135);
            this.cBOXPARITYBITS.Name = "cBOXPARITYBITS";
            this.cBOXPARITYBITS.Size = new System.Drawing.Size(121, 24);
            this.cBOXPARITYBITS.TabIndex = 9;
            this.cBOXPARITYBITS.Text = " Even";
            // 
            // cBOXSTOPBITS
            // 
            this.cBOXSTOPBITS.FormattingEnabled = true;
            this.cBOXSTOPBITS.Items.AddRange(new object[] {
            "1",
            "2"});
            this.cBOXSTOPBITS.Location = new System.Drawing.Point(160, 105);
            this.cBOXSTOPBITS.Name = "cBOXSTOPBITS";
            this.cBOXSTOPBITS.Size = new System.Drawing.Size(121, 24);
            this.cBOXSTOPBITS.TabIndex = 8;
            this.cBOXSTOPBITS.Text = " 2";
            // 
            // cBOXDATABITS
            // 
            this.cBOXDATABITS.FormattingEnabled = true;
            this.cBOXDATABITS.Items.AddRange(new object[] {
            "6",
            "7",
            "8"});
            this.cBOXDATABITS.Location = new System.Drawing.Point(160, 75);
            this.cBOXDATABITS.Name = "cBOXDATABITS";
            this.cBOXDATABITS.Size = new System.Drawing.Size(121, 24);
            this.cBOXDATABITS.TabIndex = 7;
            this.cBOXDATABITS.Text = " 8";
            // 
            // cBOXBAUDRATE
            // 
            this.cBOXBAUDRATE.FormattingEnabled = true;
            this.cBOXBAUDRATE.Items.AddRange(new object[] {
            "2400",
            "4800",
            "9600",
            "14400",
            "19200",
            "28800",
            "38400",
            "56000",
            "57600",
            "115200",
            "230400"});
            this.cBOXBAUDRATE.Location = new System.Drawing.Point(160, 45);
            this.cBOXBAUDRATE.Name = "cBOXBAUDRATE";
            this.cBOXBAUDRATE.Size = new System.Drawing.Size(121, 24);
            this.cBOXBAUDRATE.TabIndex = 6;
            this.cBOXBAUDRATE.Text = " 230400";
            // 
            // cBOXCOMPORT
            // 
            this.cBOXCOMPORT.FormattingEnabled = true;
            this.cBOXCOMPORT.Location = new System.Drawing.Point(160, 15);
            this.cBOXCOMPORT.Name = "cBOXCOMPORT";
            this.cBOXCOMPORT.Size = new System.Drawing.Size(121, 24);
            this.cBOXCOMPORT.TabIndex = 5;
            this.cBOXCOMPORT.Text = " ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 143);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Parity Bits";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 113);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Stop Bits";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Data Bits";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Baud Rate";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Com Port";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.progressBar1);
            this.groupBox2.Controls.Add(this.btnCLOSE);
            this.groupBox2.Controls.Add(this.btnOPEN);
            this.groupBox2.Location = new System.Drawing.Point(49, 231);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(187, 103);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(9, 64);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(169, 33);
            this.progressBar1.TabIndex = 2;
            this.progressBar1.Click += new System.EventHandler(this.progressBar1_Click);
            // 
            // btnCLOSE
            // 
            this.btnCLOSE.Location = new System.Drawing.Point(103, 22);
            this.btnCLOSE.Name = "btnCLOSE";
            this.btnCLOSE.Size = new System.Drawing.Size(75, 36);
            this.btnCLOSE.TabIndex = 1;
            this.btnCLOSE.Text = "CLOSE";
            this.btnCLOSE.UseVisualStyleBackColor = true;
            this.btnCLOSE.Click += new System.EventHandler(this.btnCLOSE_Click);
            // 
            // btnOPEN
            // 
            this.btnOPEN.Location = new System.Drawing.Point(9, 22);
            this.btnOPEN.Name = "btnOPEN";
            this.btnOPEN.Size = new System.Drawing.Size(88, 36);
            this.btnOPEN.TabIndex = 0;
            this.btnOPEN.Text = "OPEN";
            this.btnOPEN.UseVisualStyleBackColor = true;
            this.btnOPEN.Click += new System.EventHandler(this.btnOPEN_Click);
            // 
            // btnSENDDATA
            // 
            this.btnSENDDATA.Location = new System.Drawing.Point(6, 219);
            this.btnSENDDATA.Name = "btnSENDDATA";
            this.btnSENDDATA.Size = new System.Drawing.Size(139, 46);
            this.btnSENDDATA.TabIndex = 3;
            this.btnSENDDATA.Text = "SEND DATA";
            this.btnSENDDATA.UseVisualStyleBackColor = true;
            this.btnSENDDATA.Click += new System.EventHandler(this.btnSENDDATA_Click);
            // 
            // tBOXDATAOUT
            // 
            this.tBOXDATAOUT.Location = new System.Drawing.Point(6, 23);
            this.tBOXDATAOUT.Multiline = true;
            this.tBOXDATAOUT.Name = "tBOXDATAOUT";
            this.tBOXDATAOUT.Size = new System.Drawing.Size(279, 190);
            this.tBOXDATAOUT.TabIndex = 4;
            this.tBOXDATAOUT.TextChanged += new System.EventHandler(this.tBOXDATAOUT_TextChanged);
            // 
            // serialPort1
            // 
            this.serialPort1.BaudRate = 230400;
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnCLEARDATAOUT);
            this.groupBox3.Controls.Add(this.tBOXDATAOUT);
            this.groupBox3.Controls.Add(this.btnSENDDATA);
            this.groupBox3.Location = new System.Drawing.Point(351, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(289, 277);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Transmitter Control";
            // 
            // btnCLEARDATAOUT
            // 
            this.btnCLEARDATAOUT.Location = new System.Drawing.Point(146, 219);
            this.btnCLEARDATAOUT.Name = "btnCLEARDATAOUT";
            this.btnCLEARDATAOUT.Size = new System.Drawing.Size(139, 45);
            this.btnCLEARDATAOUT.TabIndex = 5;
            this.btnCLEARDATAOUT.Text = "CLEAR DATA OUT";
            this.btnCLEARDATAOUT.UseVisualStyleBackColor = true;
            this.btnCLEARDATAOUT.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnCLEARDATAIN);
            this.groupBox4.Controls.Add(this.tBOXDATAIN);
            this.groupBox4.Location = new System.Drawing.Point(351, 295);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(289, 304);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Receiver Control";
            // 
            // btnCLEARDATAIN
            // 
            this.btnCLEARDATAIN.Location = new System.Drawing.Point(7, 224);
            this.btnCLEARDATAIN.Name = "btnCLEARDATAIN";
            this.btnCLEARDATAIN.Size = new System.Drawing.Size(129, 74);
            this.btnCLEARDATAIN.TabIndex = 1;
            this.btnCLEARDATAIN.Text = "CLEAR DATA IN";
            this.btnCLEARDATAIN.UseVisualStyleBackColor = true;
            this.btnCLEARDATAIN.Click += new System.EventHandler(this.btnCLEARDATAIN_Click);
            // 
            // tBOXDATAIN
            // 
            this.tBOXDATAIN.Location = new System.Drawing.Point(7, 22);
            this.tBOXDATAIN.Multiline = true;
            this.tBOXDATAIN.Name = "tBOXDATAIN";
            this.tBOXDATAIN.Size = new System.Drawing.Size(276, 195);
            this.tBOXDATAIN.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button2);
            this.groupBox5.Controls.Add(this.button1);
            this.groupBox5.Controls.Add(this.tempChart);
            this.groupBox5.Location = new System.Drawing.Point(646, 12);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(670, 470);
            this.groupBox5.TabIndex = 7;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Temperature";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(106, 402);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(95, 62);
            this.button2.TabIndex = 2;
            this.button2.Text = "Stop";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(7, 402);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(93, 62);
            this.button1.TabIndex = 1;
            this.button1.Text = "Start";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // tempChart
            // 
            chartArea1.Name = "ChartArea1";
            this.tempChart.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.tempChart.Legends.Add(legend1);
            this.tempChart.Location = new System.Drawing.Point(6, 15);
            this.tempChart.Name = "tempChart";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Legend = "Legend1";
            series1.Name = "serialRead";
            this.tempChart.Series.Add(series1);
            this.tempChart.Size = new System.Drawing.Size(664, 380);
            this.tempChart.TabIndex = 0;
            this.tempChart.Text = "chart1";
            this.tempChart.Click += new System.EventHandler(this.tempChart_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.ClientSize = new System.Drawing.Size(1328, 620);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "COM PORT SERIAL";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tempChart)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cBOXPARITYBITS;
        private System.Windows.Forms.ComboBox cBOXSTOPBITS;
        private System.Windows.Forms.ComboBox cBOXDATABITS;
        private System.Windows.Forms.ComboBox cBOXBAUDRATE;
        private System.Windows.Forms.ComboBox cBOXCOMPORT;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnCLOSE;
        private System.Windows.Forms.Button btnOPEN;
        private System.Windows.Forms.Button btnSENDDATA;
        private System.Windows.Forms.TextBox tBOXDATAOUT;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnCLEARDATAOUT;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnCLEARDATAIN;
        private System.Windows.Forms.TextBox tBOXDATAIN;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.DataVisualization.Charting.Chart tempChart;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

