﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using rtChart;
using System.IO.Ports;
using System.Threading;
using System.Diagnostics;









namespace gui_demo2
{

    

    public partial class Form1 : Form
    {

        private Thread tempThread;
        private double[] tempArray = new double[50];

        kayChart serialDataChart;



        public byte[] IntToBCD(uint numericvalue, int bytesize = 1)
        {
            byte[] bcd = new byte[bytesize];
            for (int byteNo = 0; byteNo < bytesize; ++byteNo)
                bcd[byteNo] = 0;
            for (int digit = 0; digit < bytesize * 2; ++digit)
            {
                uint hexpart = numericvalue % 10;
                bcd[digit / 2] |= (byte)(hexpart << ((digit % 2) * 4));
                numericvalue /= 10;
            }
            return bcd;
        }
        static uint uint2bcd(uint ival)
        {
            return ((ival / 10) << 4) | (ival % 10);
        }
        string dataOUT;
        string dataIN;
        

        public Form1()
        {
            InitializeComponent();
        }
        /*
        private void getPerformanceCounters()
        {

            var tempCounter = new PerformanceCounter("Processor Information", "% Processor Time", "_Total");
            while (true)
            {
                tempArray[tempArray.Length - 1] = Math.Round(tempCounter.NextValue(), 0);
                Array.Copy(tempArray, 1, tempArray, 0, tempArray.Length - 1);

                if (tempChart.IsHandleCreated)
                {
                    this.Invoke((MethodInvoker)delegate { UpdateTempChart(); });

                }
                else
                {

                }
                Thread.Sleep(1000);
            }
        }

        private void UpdateTempChart()
        {
            tempChart.Series["Series1"].Points.Clear();

            for (int i = 0; i < tempArray.Length - 1; ++i) {
                tempChart.Series["Series1"].Points.AddY(tempArray[i]);
            }
        }*/

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnSENDDATA_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen) {
                dataOUT = tBOXDATAOUT.Text;
                uint x = (uint) (int) Int32.Parse(dataOUT);
                byte[] z = IntToBCD(x);
                ///byte[] b = BitConverter.GetBytes(x);

                serialPort1.Write(z, 0, 1);


            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] ports = SerialPort.GetPortNames();
            cBOXCOMPORT.Items.AddRange(ports);

            serialDataChart = new kayChart(tempChart, 40);
            serialDataChart.serieName = "serialRead";


        }

        private void btnOPEN_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort1.PortName = cBOXCOMPORT.Text;
                serialPort1.BaudRate = Convert.ToInt32(cBOXBAUDRATE.Text);
                serialPort1.DataBits = Convert.ToInt32(cBOXDATABITS.Text);
                serialPort1.StopBits = (StopBits)Enum.Parse((typeof(StopBits)), cBOXSTOPBITS.Text);
                serialPort1.Parity = (Parity)Enum.Parse((typeof(Parity)), cBOXPARITYBITS.Text);

                serialPort1.Open();
                serialPort1.Encoding = Encoding.GetEncoding("Windows-1252");
                progressBar1.Value = 1;

            }

            catch(Exception err)
            {
                MessageBox.Show(err.Message,"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCLOSE_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.Close();
                progressBar1.Value = 0;
            }
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(tBOXDATAOUT.Text != "")
            {
                tBOXDATAOUT.Text = "";

            }
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {

          

            int al = serialPort1.ReadByte();
            dataIN = al.ToString("X");
          

          
            
            this.Invoke(new EventHandler(showData));

        }

        private void showData(object sender, EventArgs e)
        {
            tBOXDATAIN.Text = dataIN;
            double data;
            bool result = Double.TryParse(dataIN, out data);
            if (result)
            {
                serialDataChart.TriggeredUpdate(data);

            }
        }

        private void btnCLEARDATAIN_Click(object sender, EventArgs e)
        {
            if (tBOXDATAIN.Text != "")
            {
                tBOXDATAIN.Text = "";

            }
        }

        private void tempChart_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {/*
            tempThread = new Thread(new ThreadStart(this.getPerformanceCounters));
            tempThread.IsBackground= true; 
            tempThread.Start();*/
        }

        private void button2_Click(object sender, EventArgs e)
        {/*
            tempThread.Suspend();*/
        }

        private void tBOXDATAOUT_TextChanged(object sender, EventArgs e)
        {

        }
    }
}